﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace wsAppMiAutoV2.Models
{
    public class VideosMultimedia
    {
        //public string RutaMedia { get; set; }
        public string NombreRutaMedia { get; set; }
        //public string RutaMini { get; set; }
        public string NombreRutaMini { get; set; }
    }
}