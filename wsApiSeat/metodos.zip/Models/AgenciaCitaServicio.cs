﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace wsAppMiAutoV2.Models
{
    public class AgenciaCitaServicio
    {
        public string IdAgencia { get; set; }
        public string Agencia { get; set; }
        public string IdMarca { get; set; }
    }
}