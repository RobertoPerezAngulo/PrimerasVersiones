﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace wsAppMiAutoV2.Models
{
    public class AsesorServicio
    {
        public string IdAgencia { get; set; }
        public string IdAsesor { get; set; }
        public string NombreAsesor { get; set; }
        public string ApellidoPaternoAsesor { get; set; }
        public string ApellidoMaternoAsesor { get; set; }
    }
}