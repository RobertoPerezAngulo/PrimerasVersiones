﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace wsAppMiAutoV2.Models
{
    public class Respuesta
    {
        public string Ok { get; set; }
        public string Mensaje { get; set; }
        public string Objeto { get; set; }
    }
}